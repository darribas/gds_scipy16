# Install howto

Install description here to be exposed on the website/ebook/pdf.
